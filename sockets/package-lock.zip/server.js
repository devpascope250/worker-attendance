/* eslint-disable @typescript-eslint/no-require-imports */
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');

const app = express();
app.use(cors({
  origin: "*", // Or specify your domains: ["http://localhost:3000", "http://192.168.0.43:3000"]
  methods: ["GET", "POST"]
}));

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

// Basic route
app.get('/', (req, res) => {
  res.json({ message: 'Socket.IO server is running!' });
});

io.on('connection', (socket) => {
  console.log('🔥 Client connected:', socket.id);

  socket.on('msg', (data) => {
    console.log('📩 Received:', data);
    // Broadcast to everyone
    io.emit('msg', `Echo: ${data}`);
  });

  socket.on('disconnect', () => {
    console.log('❌ Client disconnected:', socket.id);
  });
});

const PORT = process.env.PORT || 3001;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Socket.IO server running on port ${PORT}`);
  console.log(`📡 Accessible via: http://localhost:${PORT} and http://192.168.0.43:${PORT}`);
});